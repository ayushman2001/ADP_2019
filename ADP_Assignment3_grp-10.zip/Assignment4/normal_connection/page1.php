<!DOCTYPE html>
<html>
<body>


<form action="createadatab.php" method="get">
  Database name:<br>
  <input type="text" name="dbname" value="">
  <br>
  <br>
  Table name:<br>
  <input type="text" name="tbname">
  <br><br>
  <input type="submit" value="Create">
</form> 

</body>
</html>