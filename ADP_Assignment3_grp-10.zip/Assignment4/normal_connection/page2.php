<!DOCTYPE html>
<html>
<body>


<form action="inserttb.php" method="get">
  Name:<br>
  <input type="text" name="name" id="name">
  <br>
  <br>
  E-mail:<br>
  <input type="email" name="email" id="email">
  <br><br>
  Contact:<br>
  <input type="numbers" name="cont" id="cont", type="numbers">
  <br>
  <br>
  Address :<br>
  <input type="text" name="addrs" id="addrs">
  <br><br>
  <input type="submit" name="submit" value="Insert">
  <br><br>
</form>

<form action="displaytab.php">
<input type="submit" name="submit" value="Display">
</form>

</body>
</html>